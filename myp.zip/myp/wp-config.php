<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'clp');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '+!iVB:e_3Dn/}dc9X}0WuAU~On`LKyJ-&9qQR;n`57OA%z#$sFC{&GWE_Yg$#2P&');
define('SECURE_AUTH_KEY',  '?a3uvV<N>HUQu}/x(Ok+gL7TCH>Pyt!K*l_;74#jib[Hv07k8Oou,C+t1|TP_jws');
define('LOGGED_IN_KEY',    '[OE!=>Gcn,5A?uk{W=W|[^:1M&i;@4NjTp?pqCysZV `:Cn<cbPZ^])A+gk[${*[');
define('NONCE_KEY',        '=_U0^Bk],RVn<(WnB^;8$f`jH|u*olhEb{jz5Eh=)Q`z+D 5TBTT#x<qg,b.-X*v');
define('AUTH_SALT',        'V}G8x gpv!$@|b5#xw&x<ZH b9,k8L3GP8_SLA.19Pp}F]W%PiF/ZuY1.(DS#eR^');
define('SECURE_AUTH_SALT', '7+u7#[SIcIW,J[L+~J_N?N09_DAME Uj%HcjA9nf.7}D2&G&wgtY2Vq5VAk,/t9}');
define('LOGGED_IN_SALT',   '4l{XwfuyX ^`U),r<pm%-+0I<U]8oh;7WicFEp}~wg,-LvxRgwIGf(r#%mHte`K|');
define('NONCE_SALT',       'S2z56jVW0_`e#CuiJFc~?*_aF[5#,R5ciyaumrinUvMVqr=b`H{l7[WRxRQHz+2w');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
